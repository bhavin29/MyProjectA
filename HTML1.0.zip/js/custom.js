$(document).ready(function() {
    
	$(".select-sort").selectbox({
            onChange: function (val, inst) {

                $(inst.input[0]).children().each(function(item){
                    $(this).removeAttr('selected');
                })
                $(inst.input[0]).find('[value="'+val+'"]').attr('selected','selected');
            }

        });


	$('.loginpop-btn a').click(function (e){
        e.preventDefault();
        $('.overlay-loginpop').removeClass('close').addClass('open');
		$('.loginpop-btn').addClass("active");
    });

    $('.overlay-close').click(function (e) {
        e.preventDefault;
        $('.overlay-loginpop').removeClass('open').addClass('close');
		$('.overlay').removeClass('open').addClass('close');
        $('.loginpop-btn').removeClass("active");
        setTimeout(function(){
            $('.overlay-loginpop').removeClass('close');
			$('.overlay').removeClass('close');
		}, 500);
			$('.loginpop-btn').removeClass("active");
    });

	
	$('.modelpopup').on('click', function(e) {
		e.preventDefault();
		$(".overlay").removeClass("open");
		$("div[id=" + $(this).attr("data-related") + "]").addClass("open");
	});

});            